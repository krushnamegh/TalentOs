const express = require("express");
const router = express.Router();
const { getJobs, getJobById, createJob, updateJob, deleteJob } = require("../controllers/job.controller");
const { protect } = require("../middleware/auth");
const { roleCheck } = require("../middleware/roleCheck");
router.route("/").get(protect, getJobs).post(protect, roleCheck("admin", "recruiter"), createJob);
router.route("/:id").get(protect, getJobById).put(protect, roleCheck("admin", "recruiter"), updateJob).delete(protect, roleCheck("admin", "recruiter"), deleteJob);
module.exports = router;
