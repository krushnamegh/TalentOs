const express = require("express");
const router = express.Router();
const { getCandidates, getCandidateById, createCandidate, updateCandidate, deleteCandidate } = require("../controllers/candidate.controller");
const { protect } = require("../middleware/auth");
const { roleCheck } = require("../middleware/roleCheck");
router.route("/").get(protect, getCandidates).post(protect, roleCheck("admin", "recruiter"), createCandidate);
router.route("/:id").get(protect, getCandidateById).put(protect, roleCheck("admin", "recruiter"), updateCandidate).delete(protect, roleCheck("admin", "recruiter"), deleteCandidate);
module.exports = router;
