const Candidate = require("../models/Candidate");
const Job = require("../models/Job");

const getCandidates = async (req, res) => {
  const filter = req.query.job ? { job: req.query.job } : {};
  const candidates = await Candidate.find(filter).populate("job", "title department").populate("addedBy", "name");
  res.json(candidates);
};
const getCandidateById = async (req, res) => {
  const candidate = await Candidate.findById(req.params.id).populate("job").populate("addedBy", "name email");
  if (!candidate) return res.status(404).json({ message: "Candidate not found" });
  res.json(candidate);
};
const createCandidate = async (req, res) => {
  const { name, email, phone, skills, experience, job } = req.body;
  if (!name || !email || !job) return res.status(400).json({ message: "Name, email and job are required" });
  const jobExists = await Job.findById(job);
  if (!jobExists) return res.status(404).json({ message: "Job not found" });
  const alreadyApplied = await Candidate.findOne({ email, job });
  if (alreadyApplied) return res.status(400).json({ message: "Candidate already applied for this job" });
  const candidate = await Candidate.create({ name, email, phone, skills: skills || [], experience: experience || 0, job, addedBy: req.user._id });
  res.status(201).json(candidate);
};
const updateCandidate = async (req, res) => {
  const candidate = await Candidate.findById(req.params.id);
  if (!candidate) return res.status(404).json({ message: "Candidate not found" });
  candidate.name = req.body.name || candidate.name;
  candidate.email = req.body.email || candidate.email;
  candidate.phone = req.body.phone || candidate.phone;
  candidate.skills = req.body.skills || candidate.skills;
  candidate.experience = req.body.experience ?? candidate.experience;
  const updated = await candidate.save();
  res.json(updated);
};
const deleteCandidate = async (req, res) => {
  const candidate = await Candidate.findById(req.params.id);
  if (!candidate) return res.status(404).json({ message: "Candidate not found" });
  await candidate.deleteOne();
  res.json({ message: "Candidate deleted" });
};
module.exports = { getCandidates, getCandidateById, createCandidate, updateCandidate, deleteCandidate };
