const Job = require("../models/Job");

const getJobs = async (req, res) => {
  const jobs = await Job.find().populate("createdBy", "name email");
  res.json(jobs);
};
const getJobById = async (req, res) => {
  const job = await Job.findById(req.params.id).populate("createdBy", "name email");
  if (!job) return res.status(404).json({ message: "Job not found" });
  res.json(job);
};
const createJob = async (req, res) => {
  const { title, department, description, requirements, location } = req.body;
  if (!title || !department || !description) return res.status(400).json({ message: "Please fill all required fields" });
  const job = await Job.create({ title, department, description, requirements: requirements || [], location: location || "Remote", createdBy: req.user._id });
  res.status(201).json(job);
};
const updateJob = async (req, res) => {
  const job = await Job.findById(req.params.id);
  if (!job) return res.status(404).json({ message: "Job not found" });
  job.title = req.body.title || job.title;
  job.department = req.body.department || job.department;
  job.description = req.body.description || job.description;
  job.requirements = req.body.requirements || job.requirements;
  job.location = req.body.location || job.location;
  job.status = req.body.status || job.status;
  const updatedJob = await job.save();
  res.json(updatedJob);
};
const deleteJob = async (req, res) => {
  const job = await Job.findById(req.params.id);
  if (!job) return res.status(404).json({ message: "Job not found" });
  await job.deleteOne();
  res.json({ message: "Job deleted successfully" });
};
module.exports = { getJobs, getJobById, createJob, updateJob, deleteJob };
