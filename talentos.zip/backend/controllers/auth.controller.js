const jwt = require("jsonwebtoken");
const User = require("../models/User");
const generateToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: "7d" });

const registerUser = async (req, res) => {
  const { name, email, password, role, company } = req.body;
  if (!name || !email || !password || !company) return res.status(400).json({ message: "Please fill all fields" });
  const userExists = await User.findOne({ email });
  if (userExists) return res.status(400).json({ message: "Email already registered" });
  const user = await User.create({ name, email, password, role: role || "recruiter", company });
  if (user) {
    res.status(201).json({ _id: user._id, name: user.name, email: user.email, role: user.role, company: user.company, token: generateToken(user._id) });
  } else {
    res.status(400).json({ message: "Invalid user data" });
  }
};

const loginUser = async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (user && (await user.matchPassword(password))) {
    res.json({ _id: user._id, name: user.name, email: user.email, role: user.role, company: user.company, token: generateToken(user._id) });
  } else {
    res.status(401).json({ message: "Invalid email or password" });
  }
};

const getProfile = async (req, res) => res.json(req.user);
module.exports = { registerUser, loginUser, getProfile };
