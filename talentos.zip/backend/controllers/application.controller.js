const Application = require("../models/Application");

const getApplications = async (req, res) => {
  const filter = req.query.job ? { job: req.query.job } : {};
  const applications = await Application.find(filter)
    .populate("candidate", "name email phone skills experience")
    .populate("job", "title department")
    .populate("assignedTo", "name email");
  res.json(applications);
};
const getApplicationById = async (req, res) => {
  const application = await Application.findById(req.params.id).populate("candidate").populate("job").populate("assignedTo", "name email role");
  if (!application) return res.status(404).json({ message: "Application not found" });
  res.json(application);
};
const createApplication = async (req, res) => {
  const { candidate, job } = req.body;
  if (!candidate || !job) return res.status(400).json({ message: "Candidate and job are required" });
  const exists = await Application.findOne({ candidate, job });
  if (exists) return res.status(400).json({ message: "Application already exists" });
  const application = await Application.create({ candidate, job, stage: "Applied" });
  const populated = await Application.findById(application._id).populate("candidate", "name email skills").populate("job", "title department");
  res.status(201).json(populated);
};
const updateStage = async (req, res) => {
  const { stage } = req.body;
  const validStages = ["Applied", "Screened", "Interview 1", "Interview 2", "Offer", "Hired", "Rejected"];
  if (!validStages.includes(stage)) return res.status(400).json({ message: "Invalid stage" });
  const application = await Application.findById(req.params.id);
  if (!application) return res.status(404).json({ message: "Application not found" });
  application.stage = stage;
  const updated = await application.save();
  res.json(updated);
};
const assignInterviewer = async (req, res) => {
  const { interviewerId } = req.body;
  const application = await Application.findById(req.params.id);
  if (!application) return res.status(404).json({ message: "Application not found" });
  if (!application.assignedTo.includes(interviewerId)) {
    application.assignedTo.push(interviewerId);
    await application.save();
  }
  res.json(application);
};
const updateNotes = async (req, res) => {
  const application = await Application.findById(req.params.id);
  if (!application) return res.status(404).json({ message: "Application not found" });
  application.notes = req.body.notes;
  const updated = await application.save();
  res.json(updated);
};
const getPipelineStats = async (req, res) => {
  const filter = req.query.job ? { job: req.query.job } : {};
  const stats = await Application.aggregate([
    { $match: filter },
    { $group: { _id: "$stage", count: { $sum: 1 } } },
  ]);
  const formatted = {};
  stats.forEach((s) => { formatted[s._id] = s.count; });
  res.json(formatted);
};
module.exports = { getApplications, getApplicationById, createApplication, updateStage, assignInterviewer, updateNotes, getPipelineStats };
