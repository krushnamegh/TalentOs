const mongoose = require("mongoose");
const applicationSchema = new mongoose.Schema({
  candidate: { type: mongoose.Schema.Types.ObjectId, ref: "Candidate", required: true },
  job: { type: mongoose.Schema.Types.ObjectId, ref: "Job", required: true },
  stage: {
    type: String,
    enum: ["Applied", "Screened", "Interview 1", "Interview 2", "Offer", "Hired", "Rejected"],
    default: "Applied",
  },
  notes: { type: String, default: "" },
  assignedTo: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
}, { timestamps: true });
module.exports = mongoose.model("Application", applicationSchema);
