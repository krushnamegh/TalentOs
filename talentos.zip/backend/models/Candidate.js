const mongoose = require("mongoose");
const candidateSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String },
  resumeUrl: { type: String },
  skills: [String],
  experience: { type: Number, default: 0 },
  job: { type: mongoose.Schema.Types.ObjectId, ref: "Job", required: true },
  addedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
}, { timestamps: true });
module.exports = mongoose.model("Candidate", candidateSchema);
