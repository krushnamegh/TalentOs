const mongoose = require("mongoose");
const feedbackSchema = new mongoose.Schema({
  application: { type: mongoose.Schema.Types.ObjectId, ref: "Application", required: true },
  interviewer: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  scores: {
    technical: { type: Number, min: 1, max: 5 },
    communication: { type: Number, min: 1, max: 5 },
    problemSolving: { type: Number, min: 1, max: 5 },
    cultureFit: { type: Number, min: 1, max: 5 },
  },
  recommendation: { type: String, enum: ["Strong Yes", "Yes", "Maybe", "No", "Strong No"] },
  comments: { type: String },
}, { timestamps: true });
module.exports = mongoose.model("Feedback", feedbackSchema);
