import { useEffect, useState } from "react";
import API from "../api/axios";
import toast from "react-hot-toast";
import { Plus, X } from "lucide-react";
import styles from "./Jobs.module.css";

const Jobs = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ title:"", department:"", description:"", requirements:"", location:"Remote", status:"open" });

  const fetchJobs = async () => {
    try { const { data } = await API.get("/jobs"); setJobs(data); }
    catch (err) { toast.error("Failed to load jobs"); }
    finally { setLoading(false); }
  };
  useEffect(() => { fetchJobs(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await API.post("/jobs", { ...form, requirements: form.requirements.split(",").map((r) => r.trim()) });
      toast.success("Job posted!");
      setShowModal(false);
      setForm({ title:"", department:"", description:"", requirements:"", location:"Remote", status:"open" });
      fetchJobs();
    } catch (err) { toast.error(err.response?.data?.message || "Failed to create job"); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this job?")) return;
    try { await API.delete(`/jobs/${id}`); toast.success("Job deleted"); fetchJobs(); }
    catch (err) { toast.error("Failed to delete job"); }
  };

  if (loading) return <div style={{ padding:"28px", color:"var(--muted)" }}>Loading...</div>;

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Jobs</h1>
          <p className={styles.subtitle}>{jobs.length} positions</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}><Plus size={16}/>Post Job</button>
      </div>
      <div className={styles.grid}>
        {jobs.map((job) => (
          <div key={job._id} className={styles.jobCard}>
            <div className={styles.jobHeader}>
              <div>
                <div className={styles.jobTitle}>{job.title}</div>
                <div className={styles.jobDept}>{job.department}</div>
              </div>
              <span className={`${styles.badge} ${job.status==="open"?styles.open:styles.closed}`}>{job.status}</span>
            </div>
            <p className={styles.jobDesc}>{job.description}</p>
            <div className={styles.tags}>{job.requirements?.slice(0,3).map((r,i)=><span key={i} className={styles.tag}>{r}</span>)}</div>
            <div className={styles.jobFooter}>
              <span className={styles.location}>📍 {job.location}</span>
              <button className="btn btn-ghost" style={{ padding:"6px 12px", fontSize:"12px" }} onClick={() => handleDelete(job._id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
      {showModal && (
        <div className={styles.overlay}>
          <div className={styles.modal}>
            <div className={styles.modalHeader}>
              <h2 className={styles.modalTitle}>Post New Job</h2>
              <button className={styles.closeBtn} onClick={() => setShowModal(false)}><X size={18}/></button>
            </div>
            <form onSubmit={handleSubmit} className={styles.modalForm}>
              <div className="form-group"><label>Job Title</label><input placeholder="e.g. Senior React Developer" value={form.title} onChange={(e)=>setForm({...form,title:e.target.value})} required/></div>
              <div className="form-group"><label>Department</label><input placeholder="e.g. Engineering" value={form.department} onChange={(e)=>setForm({...form,department:e.target.value})} required/></div>
              <div className="form-group"><label>Location</label><input placeholder="Remote / On-site" value={form.location} onChange={(e)=>setForm({...form,location:e.target.value})}/></div>
              <div className="form-group"><label>Requirements (comma separated)</label><input placeholder="React, Node.js, MongoDB" value={form.requirements} onChange={(e)=>setForm({...form,requirements:e.target.value})}/></div>
              <div className="form-group"><label>Description</label><textarea rows={4} placeholder="Job description..." value={form.description} onChange={(e)=>setForm({...form,description:e.target.value})} required/></div>
              <button type="submit" className="btn btn-primary" style={{ width:"100%", justifyContent:"center" }}>Post Job</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
export default Jobs;
