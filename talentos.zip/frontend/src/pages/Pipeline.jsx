import { useEffect, useState } from "react";
import API from "../api/axios";
import toast from "react-hot-toast";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import styles from "./Pipeline.module.css";

const STAGES = ["Applied","Screened","Interview 1","Interview 2","Offer","Hired","Rejected"];
const STAGE_COLORS = { "Applied":"var(--accent)", "Screened":"var(--accent4)", "Interview 1":"var(--accent3)", "Interview 2":"var(--accent2)", "Offer":"var(--accent3)", "Hired":"#00d4aa", "Rejected":"var(--muted)" };

const Pipeline = () => {
  const [applications, setApplications] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [selectedJob, setSelectedJob] = useState("");
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const [appRes, jobRes] = await Promise.all([API.get("/applications"), API.get("/jobs")]);
      setApplications(appRes.data); setJobs(jobRes.data);
      if (jobRes.data.length > 0) setSelectedJob(jobRes.data[0]._id);
    } catch (err) { toast.error("Failed to load pipeline"); }
    finally { setLoading(false); }
  };
  useEffect(() => { fetchData(); }, []);

  const filtered = selectedJob ? applications.filter((a) => a.job?._id === selectedJob) : applications;
  const grouped = STAGES.reduce((acc, stage) => { acc[stage] = filtered.filter((a) => a.stage === stage); return acc; }, {});

  const onDragEnd = async (result) => {
    const { destination, source, draggableId } = result;
    if (!destination) return;
    if (destination.droppableId === source.droppableId) return;
    const newStage = destination.droppableId;
    setApplications((prev) => prev.map((app) => app._id === draggableId ? { ...app, stage: newStage } : app));
    try { await API.put(`/applications/${draggableId}/stage`, { stage: newStage }); toast.success(`Moved to ${newStage}`); }
    catch (err) { toast.error("Failed to update stage"); fetchData(); }
  };

  if (loading) return <div style={{ padding:"28px", color:"var(--muted)" }}>Loading pipeline...</div>;

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Pipeline</h1>
          <p className={styles.subtitle}>Drag and drop candidates between stages</p>
        </div>
        <select className={styles.jobSelect} value={selectedJob} onChange={(e) => setSelectedJob(e.target.value)}>
          <option value="">All Jobs</option>
          {jobs.map((j) => <option key={j._id} value={j._id}>{j.title}</option>)}
        </select>
      </div>
      <DragDropContext onDragEnd={onDragEnd}>
        <div className={styles.board}>
          {STAGES.map((stage) => (
            <div key={stage} className={styles.column}>
              <div className={styles.colHeader}>
                <div className={styles.colTitle}><span className={styles.colDot} style={{ background:STAGE_COLORS[stage] }}/>{stage}</div>
                <span className={styles.colCount}>{grouped[stage].length}</span>
              </div>
              <Droppable droppableId={stage}>
                {(provided, snapshot) => (
                  <div ref={provided.innerRef} {...provided.droppableProps}
                    className={`${styles.colBody} ${snapshot.isDraggingOver ? styles.dragOver : ""}`}>
                    {grouped[stage].map((app, index) => (
                      <Draggable key={app._id} draggableId={app._id} index={index}>
                        {(provided, snapshot) => (
                          <div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps}
                            className={`${styles.card} ${snapshot.isDragging ? styles.dragging : ""}`}>
                            <div className={styles.cardName}>{app.candidate?.name}</div>
                            <div className={styles.cardRole}>{app.job?.title}</div>
                            <div className={styles.cardSkills}>
                              {app.candidate?.skills?.slice(0,2).map((s,i) => <span key={i} className={styles.skillTag}>{s}</span>)}
                            </div>
                            <div className={styles.cardFooter}>
                              <div className={styles.cardAvatar}>{app.candidate?.name?.charAt(0).toUpperCase()}</div>
                              <span className={styles.cardExp}>{app.candidate?.experience} yr exp</span>
                            </div>
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                    {grouped[stage].length === 0 && <div className={styles.emptyCol}>Drop here</div>}
                  </div>
                )}
              </Droppable>
            </div>
          ))}
        </div>
      </DragDropContext>
    </div>
  );
};
export default Pipeline;
