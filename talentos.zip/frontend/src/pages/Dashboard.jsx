import { useEffect, useState } from "react";
import API from "../api/axios";
import { useAuth } from "../context/AuthContext";
import { Briefcase, Users, Clock, Target } from "lucide-react";
import styles from "./Dashboard.module.css";

const Dashboard = () => {
  const { user } = useAuth();
  const [jobs, setJobs] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [jobsRes, statsRes] = await Promise.all([API.get("/jobs"), API.get("/applications/stats")]);
        setJobs(jobsRes.data);
        setStats(statsRes.data);
      } catch (err) { console.error(err); }
      finally { setLoading(false); }
    };
    fetchData();
  }, []);

  const totalApplications = Object.values(stats).reduce((a, b) => a + b, 0);
  const openJobs = jobs.filter((j) => j.status === "open").length;

  const statCards = [
    { label:"Total Applications", value:totalApplications, icon:<Users size={20}/>, color:"var(--accent)" },
    { label:"Open Positions", value:openJobs, icon:<Briefcase size={20}/>, color:"var(--accent3)" },
    { label:"In Interview", value:(stats["Interview 1"]||0)+(stats["Interview 2"]||0), icon:<Clock size={20}/>, color:"var(--accent4)" },
    { label:"Offers Extended", value:stats["Offer"]||0, icon:<Target size={20}/>, color:"var(--accent2)" },
  ];

  if (loading) return <div className={styles.loading}>Loading...</div>;

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Dashboard</h1>
          <p className={styles.subtitle}>Welcome back, {user?.name} 👋</p>
        </div>
      </div>
      <div className={styles.statsGrid}>
        {statCards.map((s, i) => (
          <div key={i} className={styles.statCard}>
            <div className={styles.statIcon} style={{ background:s.color+"22", color:s.color }}>{s.icon}</div>
            <div className={styles.statValue} style={{ color:s.color }}>{s.value}</div>
            <div className={styles.statLabel}>{s.label}</div>
          </div>
        ))}
      </div>
      <div className={styles.twoCol}>
        <div className={styles.panel}>
          <div className={styles.panelHeader}><h2 className={styles.panelTitle}>Active Jobs</h2></div>
          {jobs.length === 0 ? <div className={styles.empty}>No jobs posted yet</div> : jobs.slice(0,5).map((job) => (
            <div key={job._id} className={styles.jobItem}>
              <div className={styles.jobInfo}>
                <div className={styles.jobTitle}>{job.title}</div>
                <div className={styles.jobMeta}>{job.department} · {job.location}</div>
              </div>
              <span className={`${styles.badge} ${job.status==="open"?styles.badgeGreen:styles.badgeGray}`}>{job.status}</span>
            </div>
          ))}
        </div>
        <div className={styles.panel}>
          <div className={styles.panelHeader}><h2 className={styles.panelTitle}>Pipeline Summary</h2></div>
          {Object.keys(stats).length === 0 ? <div className={styles.empty}>No applications yet</div> : Object.entries(stats).map(([stage, count]) => (
            <div key={stage} className={styles.funnelRow}>
              <div className={styles.funnelLabel}>{stage}</div>
              <div className={styles.funnelBarWrap}><div className={styles.funnelBar} style={{ width:`${(count/totalApplications)*100}%` }} /></div>
              <div className={styles.funnelNum}>{count}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
export default Dashboard;
