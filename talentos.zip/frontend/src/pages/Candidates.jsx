import { useEffect, useState } from "react";
import API from "../api/axios";
import toast from "react-hot-toast";
import { Plus, X } from "lucide-react";
import styles from "./Candidates.module.css";

const Candidates = () => {
  const [candidates, setCandidates] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name:"", email:"", phone:"", skills:"", experience:0, job:"" });

  const fetchAll = async () => {
    try {
      const [cRes, jRes] = await Promise.all([API.get("/candidates"), API.get("/jobs")]);
      setCandidates(cRes.data); setJobs(jRes.data);
    } catch (err) { toast.error("Failed to load data"); }
    finally { setLoading(false); }
  };
  useEffect(() => { fetchAll(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const candidate = await API.post("/candidates", { ...form, skills: form.skills.split(",").map((s) => s.trim()) });
      await API.post("/applications", { candidate: candidate.data._id, job: form.job });
      toast.success("Candidate added to pipeline!");
      setShowModal(false);
      setForm({ name:"", email:"", phone:"", skills:"", experience:0, job:"" });
      fetchAll();
    } catch (err) { toast.error(err.response?.data?.message || "Failed to add candidate"); }
  };

  if (loading) return <div style={{ padding:"28px", color:"var(--muted)" }}>Loading...</div>;

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Candidates</h1>
          <p className={styles.subtitle}>{candidates.length} total candidates</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}><Plus size={16}/>Add Candidate</button>
      </div>
      <div className={styles.tableWrap}>
        <table className={styles.table}>
          <thead><tr><th>Name</th><th>Email</th><th>Job</th><th>Skills</th><th>Experience</th></tr></thead>
          <tbody>
            {candidates.length === 0 ? (
              <tr><td colSpan={5} className={styles.empty}>No candidates yet</td></tr>
            ) : candidates.map((c) => (
              <tr key={c._id}>
                <td className={styles.nameCell}><div className={styles.avatar}>{c.name.charAt(0).toUpperCase()}</div>{c.name}</td>
                <td>{c.email}</td>
                <td>{c.job?.title || "—"}</td>
                <td><div className={styles.tags}>{c.skills?.slice(0,3).map((s,i)=><span key={i} className={styles.tag}>{s}</span>)}</div></td>
                <td>{c.experience} yr{c.experience !== 1 ? "s" : ""}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showModal && (
        <div className={styles.overlay}>
          <div className={styles.modal}>
            <div className={styles.modalHeader}>
              <h2 className={styles.modalTitle}>Add Candidate</h2>
              <button className={styles.closeBtn} onClick={() => setShowModal(false)}><X size={18}/></button>
            </div>
            <form onSubmit={handleSubmit} className={styles.modalForm}>
              <div className="form-group"><label>Full Name</label><input placeholder="Candidate name" value={form.name} onChange={(e)=>setForm({...form,name:e.target.value})} required/></div>
              <div className="form-group"><label>Email</label><input type="email" placeholder="candidate@email.com" value={form.email} onChange={(e)=>setForm({...form,email:e.target.value})} required/></div>
              <div className="form-group"><label>Phone</label><input placeholder="+91 99999 99999" value={form.phone} onChange={(e)=>setForm({...form,phone:e.target.value})}/></div>
              <div className="form-group"><label>Skills (comma separated)</label><input placeholder="React, Node.js" value={form.skills} onChange={(e)=>setForm({...form,skills:e.target.value})}/></div>
              <div className="form-group"><label>Years of Experience</label><input type="number" min="0" value={form.experience} onChange={(e)=>setForm({...form,experience:e.target.value})}/></div>
              <div className="form-group"><label>Applying For</label>
                <select value={form.job} onChange={(e)=>setForm({...form,job:e.target.value})} required>
                  <option value="">Select a job</option>
                  {jobs.map((j)=><option key={j._id} value={j._id}>{j.title}</option>)}
                </select>
              </div>
              <button type="submit" className="btn btn-primary" style={{ width:"100%", justifyContent:"center" }}>Add to Pipeline</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
export default Candidates;
