import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { LayoutDashboard, Briefcase, Users, KanbanSquare, LogOut, Zap } from "lucide-react";
import styles from "./Navbar.module.css";
const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const handleLogout = () => { logout(); navigate("/login"); };
  const navItems = [
    { icon: <LayoutDashboard size={16} />, label: "Dashboard", path: "/dashboard" },
    { icon: <KanbanSquare size={16} />, label: "Pipeline", path: "/pipeline" },
    { icon: <Briefcase size={16} />, label: "Jobs", path: "/jobs" },
    { icon: <Users size={16} />, label: "Candidates", path: "/candidates" },
  ];
  const initials = user?.name?.split(" ").map((n) => n[0]).join("").toUpperCase();
  return (
    <aside className={styles.sidebar}>
      <div className={styles.logo}>
        <div className={styles.logoIcon}><Zap size={16} /></div>
        <span className={styles.logoText}>TalentOS</span>
      </div>
      <nav className={styles.nav}>
        {navItems.map((item) => (
          <NavLink key={item.path} to={item.path}
            className={({ isActive }) => `${styles.navItem} ${isActive ? styles.active : ""}`}>
            {item.icon}<span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
      <div className={styles.footer}>
        <div className={styles.userCard}>
          <div className={styles.avatar}>{initials}</div>
          <div className={styles.userInfo}>
            <div className={styles.userName}>{user?.name}</div>
            <div className={styles.userRole}>{user?.role}</div>
          </div>
        </div>
        <button className={styles.logoutBtn} onClick={handleLogout}>
          <LogOut size={14} /> Logout
        </button>
      </div>
    </aside>
  );
};
export default Navbar;
